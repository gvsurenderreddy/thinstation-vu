#ifndef __ASM_GENERIC_SEGMENT_H
#define __ASM_GENERIC_SEGMENT_H
/*
 * Only here because we have some old header files that expect it...
 *
 * New architectures probably don't want to have their own version.
 */

#endif /* __ASM_GENERIC_SEGMENT_H */

#ifndef _CRYPTO_CAST_COMMON_H
#define _CRYPTO_CAST_COMMON_H

extern const u32 cast_s1[256];
extern const u32 cast_s2[256];
extern const u32 cast_s3[256];
extern const u32 cast_s4[256];

#endif
